package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Service;

import com.example.demo.entity.InstaPost;
import com.example.demo.repository.InstaRepository;

@Service


public class InstaServiceImpl implements InstaService {
	
	@Autowired

	
	private InstaRepository instaRepository;

	public InstaPost createInsta(InstaPost insta) {
		// TODO Auto-generated method stub
		return instaRepository.save(insta);
	}

	@Override
	 public Page<InstaPost> getSortedInsta1(int pageNo, int pageSize, String sortBy) {
	      PageRequest pageRequest = PageRequest.of(pageNo, pageSize, Sort.by(new Order(Sort.Direction.DESC, sortBy)));
	      return instaRepository.findAll(pageRequest);
	   }
	

	@Override
	public InstaPost getInstaById(Long id) {
		// TODO Auto-generated method stub
		return instaRepository.findById(id).orElse(null);
		
	}

	@Override
	public InstaPost getInstaByIdAndPostedBy(Long id, String postedBy) {
		// TODO Auto-generated method stub
		return instaRepository.findByPostIdAndPostedBy(id, postedBy).orElse(null);
		
	}
	
	public Page<InstaPost> getPaginatedInsta(Pageable pageable) {
	      return instaRepository.findAll(pageable);
	   }

	@Override
	public Page<InstaPost> getPaginatedInsta(PageRequest of) {
		// TODO Auto-generated method stub
		return instaRepository.findAll(of);
	}

	
	
	

}
