package com.example.demo.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import com.example.demo.entity.InstaPost;

public interface InstaService {

	InstaPost createInsta(InstaPost insta);

	

	InstaPost getInstaById(Long id);

	InstaPost getInstaByIdAndPostedBy(Long id, String postedBy);

	



	Page<InstaPost> getSortedInsta1(int pageNo, int pageSize, String sortBy);



	Page<InstaPost> getPaginatedInsta(PageRequest of);

}
