package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.InstaPost;
import com.example.demo.service.InstaService;

@RestController

public class InstaController {
	
	@Autowired
	

	   private InstaService instaService;
	 

	   @PostMapping("insta")
	   public InstaPost createInsta(@RequestBody InstaPost insta) {
	      return instaService.createInsta(insta);
	   }

	   

	   @GetMapping("insta/{id}")
	   public InstaPost getInstaById(@PathVariable Long id) {
	      return instaService.getInstaById(id);
	   }

	   @GetMapping("insta/{id}/{postedBy}")
	   public InstaPost getInstaByIdAndPostedBy(@PathVariable Long id, @PathVariable String postedBy) {
	      return instaService.getInstaByIdAndPostedBy(id, postedBy);
	   }
	   
	   @GetMapping("/sort")
	   public Page<InstaPost> getSortedInsta1(
	      @RequestParam(defaultValue = "0") int pageNo,
	      @RequestParam(defaultValue = "10") int pageSize,
	      @RequestParam(defaultValue = "postedAt") String sortBy) {

	      return instaService.getSortedInsta1(pageNo, pageSize, sortBy);
	   }
	   
	   @GetMapping("/paginate")
	   public Page<InstaPost> getPaginatedInsta(
	      @RequestParam(defaultValue = "0") int pageNo,
	      @RequestParam(defaultValue = "10") int pageSize) {

	      return instaService.getPaginatedInsta(PageRequest.of(pageNo, pageSize));
	   }
	
	

}
